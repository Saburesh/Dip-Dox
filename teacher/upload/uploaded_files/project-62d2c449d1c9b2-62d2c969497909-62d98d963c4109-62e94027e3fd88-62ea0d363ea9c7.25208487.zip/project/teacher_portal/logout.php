<?php

session_start();
session_unset();
session_destroy();
echo "Logout Successful";
echo "<br>";
echo "Redirecting to login page";
header( "refresh:3; url = /project/login/login_form.php");
?>