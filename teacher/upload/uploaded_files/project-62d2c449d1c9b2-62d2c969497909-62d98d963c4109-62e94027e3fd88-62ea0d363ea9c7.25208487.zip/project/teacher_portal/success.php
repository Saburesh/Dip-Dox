<html>
    <head>
        <title>
            login
        </title>
        <link rel="stylesheet" href ='/project/teacher_portal/success.css'>
            <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    </head>
    <body>
    <h1>hello</h1>
    <?php
    session_start();
    $con=mysqli_connect("localhost","root","", "test");
    echo $_SESSION['username'];
    $uname = $_SESSION['username'];
    echo "<br/>";
    echo "<br/><br/>";
    echo $_SESSION['email'];
    print "<a href= '/project/teacher_portal/logout.php'>logout</a>";
    $query = "SELECT * FROM uploaded_files WHERE  uname = '$uname';";
    echo "Your files  : ";
    echo "<br/><br/>";
    echo "<br/><br/> <table border='1'>";
    $rows = mysqli_query($con,$query);
    $rows = mysqli_fetch_array($rows);
    if($rows != NULL){
        
        echo "<tr><th>sl.no.</th><th>File name</th><th>Link</th><th>Date</th><th>Subject</th></tr>";
        echo $rows[1];
        while($rows[2]!=NULL){
              
            $i=1;
            echo "<tr><td>$i</td><td>$rows[1]</td><td></td><td>$rows[4]</td><td>$rows[5]</td></tr>";
            $i++;
        }
        echo "</table></br>";
    } else{
        echo "No files uploaded yet!! </br> <a href='/project/upload/upload_form.php'>Upload new files </a>";
    }

    ?>
    

   <section class="footer">

<div class="box-container">

    <p1>"<b>Diploma documents</b>" provides you all the essential learning resources.<br>
        This website is to provide syllabus copies, notes, question papers, link to
        educational videos, media, text-books for all semesters in a PDF format.</p1>
    </br>

</div>

</section>
    </body>
</html>