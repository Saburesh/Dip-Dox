<?php
session_start();
$file=$_FILES['file'];
$file_tmp_name=$file['tmp_name'];
$t_name=$_SESSION['username'];
echo "$t_name";
$sub=$_POST['sub'];
$dis_name=$_POST['dis_name'];

$pattern = "/ /";
$file_orig_name = $file['name'];        //stores orignal file name in database
$file_name = $file['name'];

$ext_seperator = explode(".",$file_name);
$ext = end($ext_seperator);

$file_name = $ext_seperator[0];

$conn=mysqli_connect("localhost","root","","test");


if($file['error']!=0){                  // checks for error while uploading.
    echo 'error in uploading the file'; 
}
else{
    if($file['size'] > 11000){          // if loop executes when file size is less than 11 MB 
        $file_id=uniqid("$file_name-",true).".".$ext;       //creates a unique ID for each file and attaches the orignal name to the unique id.
        $file_dest = "C: wamp64 www project upload uploaded_files ".$file_id;
        $file_dest_system = "C:\\wamp64\\www\\project\\upload\\uploaded_files\\".$file_id;
        move_uploaded_file($file_tmp_name,$file_dest_system);
        $query="INSERT INTO uploaded_files(file_disp_name, location, uname, subject) VALUES('$dis_name', '$file_dest', '$t_name', '$sub')";
              //INSERT INTO uploaded_files(file_disp_name, location, uname, subject) VALUES('$dis_name', '$file_dest', '$t_name', '$sub');  
        if(mysqli_query($conn,$query)){
            echo "success";
        }
        else{
            echo "failed";
        }
        //echo $query;
        echo "<br><br>";
        echo "<br><br>";
        $DB_Location = "SELECT location FROM uploaded_files WHERE file_disp_name='$dis_name'";
        if($DB_Location=mysqli_query($conn,$DB_Location))
        $DB_Location=mysqli_fetch_array($DB_Location);
        $DB_Location=$DB_Location[0];
        $DB_Location = preg_split($pattern, $DB_Location);
        $DB_Location1 = implode("\\",$DB_Location);
        print "$DB_Location1";
        print "<br/>";
        print "<a href='/project/upload/uploaded_files/$file_id'>file</a>";
    }
    else{echo 'File size too big, please upload something less than 10 Megabytes.';}
}



?>