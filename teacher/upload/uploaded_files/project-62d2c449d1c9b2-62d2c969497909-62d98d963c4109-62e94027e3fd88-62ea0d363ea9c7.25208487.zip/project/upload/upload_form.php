<html>
<body>
<?php session_start();
$uname = $_SESSION['username'];
print "$uname";
?>
<p>
<form action="upload.php" method="post" enctype="multipart/form-data">
<br/><br/>
    <!-- Teacher Name : <input type="text" name="t_name"/><br/> -->

    Subject : <input type="text" name="sub"/><br/>

    File Display Name : <input type="text" name="dis_name"/><br/>

    
    <br/>
    <br/>
    Select file to upload: 
    <br/><br/>
    <input type="file" name="file" id="file" onchange="Filevalidation()" />
    <br/><br/>
    <input type="submit" value="Upload File" name="submit" id="submit">
</form>
</p>
<p id="size"></p>
</body>
<script>
    Filevalidation = () => {
        const fi = document.getElementById('file');
        // Check if any file is selected.
        if (fi.files.length > 0) {
            for (const i = 0; i <= fi.files.length - 1; i++) {
                
                const fsize = fi.files.item(i).size;
                const file = Math.round((fsize / 1024));
                // The size of the file.
                if (file >= 11264) {
                    alert(
                        "File too Big, please select a file less than 10mb");
                        //document.getElementById('submit').disabled = true;
                        window.location.reload(true);
                } 
                // else if (file < 2048) {
                //     alert("File too small, please select a file greater than 2mb");
                // }
                else {
                    document.getElementById('size').innerHTML = '<b>'
                    + file + '</b> KB';
                }
            }
        }
    }
</script>
</html>