<html>
<head><title>index page</title></head>
<body bgcolor="grey">
<center><h1>
<a href="/project/reg/register_form.php">Register</a>
<br>
<a href="/project/login/login_form.php">Login</a>
<br>
<a href="/project/upload/upload_form.php">upload</a>
<br>
<a href="/project/admin/admin1.html">Admin Login</a>
</center>
</h1>
</body>
</html>