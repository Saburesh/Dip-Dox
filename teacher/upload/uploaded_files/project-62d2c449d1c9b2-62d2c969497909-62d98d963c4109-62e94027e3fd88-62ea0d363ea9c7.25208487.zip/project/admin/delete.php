<?php
$con=mysql_connect("localhost","root","");
if(!$con)
{
die('error in connection'.mysql_error());
}
mysql_select_db("uday",$con);
$name=$_GET['nm'];
$query="delete from login where name='$name' ";
$delete=mysql_query($query,$con);
if($delete){
    echo "<script type='text/javascript'>alert('successfully deleted');</script>";
}
else{
    echo "<script type='text/javascript'>alert('operation uncessfull');</script>";
}

?>