<?php
$id=$_POST['admin'];
$pass=$_POST['pass'];
if($id=="admin" && $pass=="12345"){
    header("Location:dash.php");
}
else{
    echo '<script>alert("INCORRECT PASSWORD")</script>';  
}
?>