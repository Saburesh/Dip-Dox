<html>
    <head><title>Join Now</title>
    <link rel="stylesheet" href ='/project/login/teacherLogin.css'>
            <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'></head>
    <body>
    <div class="box">
        <div class="title"><h3>Register!</h3></div>
        <form method="post" action="register.php">
            
                        <input type="text" name="fname" placeholder="Enter first name"/> 
                    
                       <input type="text" name="lname" placeholder="Enter last name"/> 
                    
                        <input type="text" name="email" placeholder="Enter email-id"/> 
                    
                        <input type="password" name="pass" placeholder="Enter password"/>
                    
                        <input type="password" placeholder="Confirm password"/>
                        
                        <!--Confirm passwoed does not have a name because it wil be validated
                        on this page itself using JS and only the first password will be sent.-->
                       <br>  
                    <input type="submit" value="Register"/>
                  
                Already registered click here to <a href="/project/login/login_form.php">login!</a>
               
        </form>

    </div>
    <div class="image"><img src="cry.png"></div>
    <section class="footer">

    <div class="box-container">

        <p1>"<b>Diploma documents</b>" provides you all the essential learning resources.<br>
            This website is to provide syllabus copies, notes, question papers, link to
            educational videos, media, text-books for all semesters in a PDF format.</p1>
        </br>

    </div>

</section>
    </body>
</html>