<?php

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$pass = $_POST['pass'];
$full_name=$fname." ".$lname; //full_name is first_name + white_space + last_name.

$con = mysqli_connect("localhost", "root", "", "test");

if(!$con){
    die('error in connection'.mysqli_error);
}
    
$query="INSERT INTO login VALUES('$full_name', '$email', '$pass');";
if(mysqli_query($con,$query)){

    print"<h1>Registeration successfull <br/> Redirection to Login page.</h1>";
    header( "refresh:3; url = /project/login/login_form.php"); //redirects to login page after 3 seconds.
}
else{
    echo "Failed";
}

?>