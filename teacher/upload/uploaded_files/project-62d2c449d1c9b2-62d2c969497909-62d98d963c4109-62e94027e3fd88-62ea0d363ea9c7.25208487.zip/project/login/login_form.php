<html>
    <head>
        <title>
            login
        </title>
        <link rel="stylesheet" href ='/project/login/teacherLogin.css'>
            <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    </head>
    <body>
        <div class="box">
        <div class="title"><h2>Login!</h2></div>
            <form method="post" action="login.php">
                   
                <input type="text" name="email" placeholder="Enter email-id">    
                <input type="password" name="pass" placeholder="Enter password">
                    
                <input type="submit" value="Submit">
                <br><br>  
                Not a member yet? <a href="/project/reg/register_form.php"> join now!</a>
                    
            </form>
        </div>
    <div class="image"><img src="orb.png"></div>
    <section class="footer">

<div class="box-container">

    <p1>"<b>Diploma documents</b>" provides you all the essential learning resources.<br>
        This website is to provide syllabus copies, notes, question papers, link to
        educational videos, media, text-books for all semesters in a PDF format.</p1>
    </br>

</div>

</section>
    </body>
</html>