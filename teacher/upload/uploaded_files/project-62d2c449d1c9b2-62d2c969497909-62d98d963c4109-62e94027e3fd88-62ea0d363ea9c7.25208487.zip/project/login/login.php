<?php
    
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $query;
    $con=mysqli_connect("localhost","root","");
    if(!$con){
        die('error in connection'.mysqli_error());
    }
    mysqli_select_db($con,"test");
    
    $query="select pass from login where email='$email';";
    $result=mysqli_query($con,$query);
    $row = mysqli_fetch_array($result);
    
    $email_exists="SELECT COUNT(*) FROM login WHERE email = '$email';"; //query statement to check if the email exists
    $number_of_users = mysqli_query($con,$email_exists);
    $email_exists = mysqli_fetch_array($number_of_users);
    //echo $email_exists[0];
    //echo "<br>1<br>";
    if(($email_exists[0]) && ($pass!="")){
        //echo "<br>2<br>";
        $row = mysqli_fetch_array($row = mysqli_query($con,"select * from login where email = '$email';"));                               // checks if the email exists and the given password is not empty
        if($row[2]==$pass){
            $result=mysqli_query($con,"SELECT name FROM login WHERE email='$email';");
            $row = mysqli_fetch_array($result);
            session_start();
            $_SESSION['email']=$email;
            $_SESSION['username']=$row[0];
            header("Location: /project/teacher_portal/success.php");
            //echo "<br>3<br>";
        }
        else{
            echo "Invalid password.";
            print "<br/>";
            print "<br/>";
            print "<a href='/project/login/login_form.php'>_Retry Login</a>";
            //echo "<br>4<br>";
        }
    }
    else{
        echo "Invalid email";
        print "<br/>";
        print "<br/>";
        print "<a href='/project/login/login_form.php'>Retry Login</a>";
        //echo "<br>5<br>";
    }
    mysqli_close($con); 
    //echo "<br>".$email." ".$pass;

?>